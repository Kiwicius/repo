
# Tier List × Notion × Next.js

เว็บจัด Tier List แบบลาก-ปล่อย แล้วซิงก์กลับไปที่ Notion อัตโนมัติ

## สิ่งที่ต้องมี
1. สร้าง **Notion integration** แล้วเอา Secret มาใส่ `.env.local` ในคีย์ `NOTION_TOKEN`
2. ฐานข้อมูลใน Notion (Database) ที่มี Properties:
   - **Name** (Title)
   - **Tier** (Select: S, A, B, C, D)
   - **Order** (Number)
   - **Image** (Files & media) — optional
   - **Notes** (Text) — optional

> คุณสามารถแก้ชื่อ property ได้ใน `.env.local` (ดู `.env.example`).

## เริ่มต้น
```bash
pnpm i   # หรือ npm i / yarn
cp .env.example .env.local
# ใส่ NOTION_TOKEN และ NOTION_DATABASE_ID
pnpm dev
```

เปิด `http://localhost:3000`

## โครงสร้าง
- `app/page.tsx` ดึงข้อมูลจาก Notion (server) และส่งให้คอมโพเนนต์ Board (client)
- `components/Board.tsx` เรนเดอร์คอลัมน์ Tier และจัดการลาก-ปล่อยด้วย SortableJS
- `app/api/items/route.ts` GET รายการ, PATCH อัปเดต Tier/Order กลับไปที่ Notion
- `lib/notion.ts` ฟังก์ชันเชื่อมต่อ Notion API

## หมายเหตุ
- URL รูปไฟล์ที่อัปโหลดเข้า Notion จะหมดอายุในช่วงเวลาหนึ่ง (พฤติกรรมปกติของ Notion). ถ้าต้องการลิงก์รูปถาวร แนะนำให้ใช้ **external image URL**.
- อัตราการยิง API ของ Notion มี rate limit. โค้ดนี้อัปเดตเฉพาะคอลัมน์ที่ drop ลง เพื่อลดจำนวนคำขอ


---

## Deploy ขึ้น Vercel (ทางลัดสำหรับมือถือ)
1. สร้าง GitHub repo ใหม่ แล้วอัปโหลดโปรเจกต์นี้ขึ้นไป
2. เข้า **Vercel** > New Project > Import จาก GitHub repo
3. ตั้งค่า **Environment Variables** บน Vercel (Project Settings > Env):
   - `NOTION_TOKEN` = (Internal Integration Token จาก Notion)
   - `NOTION_DATABASE_ID` = (ID ของ Database)
   - (ถ้าชื่อพร็อพต่างจากค่าเริ่มต้น) ตั้งเพิ่ม:
     - `NOTION_PROP_TITLE`, `NOTION_PROP_TIER`, `NOTION_PROP_ORDER`, `NOTION_PROP_IMAGE`, `NOTION_PROP_NOTES`
4. กด **Deploy** → ได้โดเมน `https://<your-app>.vercel.app` พร้อมใช้งาน
5. ถ้าปรับฐานข้อมูล/พร็อพใน Notion ให้กด **Redeploy** อีกครั้งเพื่อให้ UI ตรงกับข้อมูล

> เคล็ดลับ: ในหน้า Database ของ Notion ต้องกด **Add connections** แล้วเลือก Integration ที่คุณสร้างไว้ ไม่งั้น API จะอ่าน/เขียนไม่ได้
