
import { NextRequest, NextResponse } from 'next/server'
import { listItems, updateItem } from '@/lib/notion'
import { z } from 'zod'

export async function GET() {
  try {
    const items = await listItems()
    return NextResponse.json({ items })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Unknown error' }, { status: 500 })
  }
}

const PatchSchema = z.object({
  id: z.string(),
  tier: z.enum(['S','A','B','C','D']).optional(),
  order: z.number().int().nonnegative().optional()
})

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json()
    const parsed = PatchSchema.parse(body)
    await updateItem(parsed.id, parsed)
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Invalid payload' }, { status: 400 })
  }
}
