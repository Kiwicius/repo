
import Board from '@/components/Board'
import { listItems } from '@/lib/notion'

export const revalidate = 0;

export default async function Page() {
  const initial = await listItems();
  return <Board initialItems={initial} />;
}
