
export default function Page() {
  return <h1>Tier List Notion App พร้อมใช้งาน</h1>
}
