
'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import Sortable from 'sortablejs'
import type { Item, Tier } from '@/lib/notion'

type Props = { initialItems: Item[] }

const TIERS: Tier[] = ['S','A','B','C','D']

export default function Board({ initialItems }: Props) {
  const [items, setItems] = useState<Item[]>(initialItems)
  const [busy, setBusy] = useState(false)

  const groups = useMemo(() => {
    const by: Record<Tier, Item[]> = { S:[],A:[],B:[],C:[],D:[] }
    for (const it of items) by[it.tier].push(it)
    TIERS.forEach(t => by[t].sort((a,b) => a.order - b.order))
    return by
  }, [items])

  const containersRef = useRef<Record<Tier, HTMLElement|null>>({S:null,A:null,B:null,C:null,D:null})

  useEffect(() => {
    const sortables: Sortable[] = []
    TIERS.forEach(tier => {
      const el = containersRef.current[tier]
      if (!el) return
      const s = new Sortable(el, {
        group: 'tiers',
        animation: 150,
        ghostClass: 'dragging',
        draggable: '.card',
        onEnd: async (evt) => {
          const fromTier = evt.from.getAttribute('data-tier') as Tier
          const toTier = evt.to.getAttribute('data-tier') as Tier
          const movedId = (evt.item as HTMLElement).dataset.id!
          // recompute local state
          setItems(prev => {
            const copy = prev.map(x => ({...x}))
            const moved = copy.find(x => x.id === movedId)!
            // remove from old list order
            const fromList = copy.filter(x => x.tier === fromTier && x.id !== movedId).sort((a,b)=>a.order-b.order)
            const toList = copy.filter(x => x.tier === toTier && x.id !== movedId).sort((a,b)=>a.order-b.order)
            // Insert at newIndex
            toList.splice(evt.newIndex, 0, { ...moved, tier: toTier })
            // Reassign orders starting at 0
            const reassign = (list: Item[]) => list.map((it, idx) => ({...it, order: idx}))
            const updated = [
              ...copy.filter(x => x.tier !== fromTier && x.tier !== toTier),
              ...reassign(fromList).map(it => ({...it, tier: fromTier})),
              ...reassign(toList)
            ]
            return updated
          })
          // flush to server (update moved item + neighbors order for target tier)
          try {
            setBusy(true)
            const toChildren = Array.from(evt.to.children) as HTMLElement[]
            // minimal updates: only target tier orders
            await Promise.all(toChildren.map((node, idx) => {
              const id = node.dataset.id!
              return fetch('/api/items', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, tier: toTier, order: idx })
              })
            }))
          } finally {
            setBusy(false)
          }
        }
      })
      sortables.push(s)
    })
    return () => sortables.forEach(s => s.destroy())
  }, [])

  return (
    <div className="container">
      <div className="header">
        <h1>Tier List</h1>
        <button className="button" disabled={busy} onClick={async ()=>{
          setBusy(true)
          try {
            const res = await fetch('/api/items')
            const data = await res.json()
            setItems(data.items)
          } finally { setBusy(false) }
        }}>{busy ? 'กำลังบันทึก...' : 'รีเฟรชจาก Notion'}</button>
      </div>

      <div className="grid">
        {TIERS.map(tier => (
          <div key={tier} className={`col tier-${tier}`}>
            <h2>Tier {tier}</h2>
            <div
              ref={(el)=> (containersRef.current[tier]=el)}
              data-tier={tier}
            >
              {groups[tier].map(it => (
                <Card key={it.id} item={it} />
              ))}
            </div>
          </div>
        ))}
      </div>

      <p className="small" style={{marginTop: 12}}>
        เคล็ดลับ: รูปจาก Notion แบบอัปโหลดจะหมดอายุเป็นช่วง ๆ ของ URL (ข้อจำกัดของ Notion) — ถ้าต้องการคงที่ให้ใช้ external image URL
      </p>
    </div>
  )
}

function Card({ item }: { item: Item }) {
  return (
    <div className="card" data-id={item.id}>
      {item.imageUrl ? <img src={item.imageUrl} alt={item.title} /> : null}
      <div style={{display:'flex', flexDirection:'column'}}>
        <div className="title">{item.title}</div>
        {item.notes ? <div className="notes">{item.notes}</div> : null}
      </div>
    </div>
  )
}
