
import { Client } from '@notionhq/client'

export type Tier = 'S'|'A'|'B'|'C'|'D'

export type Item = {
  id: string
  title: string
  tier: Tier
  order: number
  imageUrl?: string | null
  notes?: string | null
}

const notion = new Client({ auth: process.env.NOTION_TOKEN })

const DB_ID = process.env.NOTION_DATABASE_ID!
const PROP_TITLE = process.env.NOTION_PROP_TITLE || 'Name'
const PROP_TIER = process.env.NOTION_PROP_TIER || 'Tier'
const PROP_ORDER = process.env.NOTION_PROP_ORDER || 'Order'
const PROP_IMAGE = process.env.NOTION_PROP_IMAGE || 'Image'
const PROP_NOTES = process.env.NOTION_PROP_NOTES || 'Notes'

export async function listItems(): Promise<Item[]> {
  if (!DB_ID) throw new Error('Missing NOTION_DATABASE_ID')
  const res = await notion.databases.query({
    database_id: DB_ID,
    page_size: 100,
    sorts: [
      { property: PROP_TIER, direction: 'ascending' },
      { property: PROP_ORDER, direction: 'ascending' }
    ]
  })
  const items: Item[] = res.results.map((page: any) => {
    const p = page.properties
    const title = p[PROP_TITLE]?.title?.[0]?.plain_text ?? '(ไม่มีชื่อ)'
    const tierOpt = p[PROP_TIER]?.select?.name ?? 'D'
    const order = p[PROP_ORDER]?.number ?? 9999

    // image could be files or url prop. Try best-effort
    let imageUrl: string | null = null
    const imgProp = p[PROP_IMAGE]
    if (imgProp?.files?.length) {
      const f = imgProp.files[0]
      if (f.type === 'external') imageUrl = f.external.url
      if (f.type === 'file') imageUrl = f.file.url // expires after some time
    }
    const notesArr = p[PROP_NOTES]?.rich_text ?? []
    const notes = notesArr.length ? notesArr.map((n: any)=>n.plain_text).join('') : null

    return {
      id: page.id,
      title,
      tier: (tierOpt || 'D') as any,
      order,
      imageUrl,
      notes
    }
  })
  return items
}

export async function updateItem(
  id: string,
  data: Partial<Pick<Item, 'tier'|'order'>>
) {
  const properties: any = {}
  if (data.tier) {
    properties[PROP_TIER] = { select: { name: data.tier } }
  }
  if (typeof data.order === 'number') {
    properties[PROP_ORDER] = { number: data.order }
  }
  return notion.pages.update({ page_id: id, properties })
}
